Create project framework
[X] App.js with router init
[X] Rendering and other lib utils
[X] Requester module
[X] LocalStorage and other utilities
[X] User API module

Implement exam solution

[ ] Adapt user API module
[ ] Create Collection API module 
[ ] Implement views
  [ ] Home page
  [ ] Catalog
  [ ] Login
  [ ] Register
  [ ] Navigation
  [ ] Create Form
  [ ] Details
  [ ] Form
  [ ] BONUS